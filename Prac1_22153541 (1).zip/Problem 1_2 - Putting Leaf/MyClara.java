/* PERMITTED COMMANDS
   move(); turnLeft(); putLeaf(); removeLeaf();
*/
   
class MyClara extends Clara { 
    /**
     * In the 'run()' method you can write your program for Clara 
     */
    void run() {
        // TODO: Write your code below
        move();
        putLeaf();
        move();
        move();
        putLeaf();
        move();
        move();
        putLeaf();
        move();
        move();
        putLeaf();
        move();
        move();
        putLeaf();
        move();
        move();
        move();



    }
}