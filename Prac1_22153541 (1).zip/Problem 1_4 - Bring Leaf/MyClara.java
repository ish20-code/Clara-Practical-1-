/* PERMITTED COMMANDS
   move(); turnLeft(); putLeaf(); removeLeaf();
*/
   
class MyClara extends Clara { 
    /**
     * In the 'run()' method you can write your program for Clara 
     */
    void run() {
        // TODO: Write your code below
        turnRight();
        move();
        turnLeft();
        move();
        move();
        move();
        move();
        move();
        move();
        turnLeft();
        move();
        move();
        move();
        removeLeaf();
        turnLeft();
        turnLeft();
        move();
        move();
        move();
        turnRight();
        move();
        move();
        move();
        move();
        move();
        move();
        turnLeft();
        move();
        putLeaf();
        turnRight();
        turnRight();
        move();
        move();
        turnRight();
        




    }
}