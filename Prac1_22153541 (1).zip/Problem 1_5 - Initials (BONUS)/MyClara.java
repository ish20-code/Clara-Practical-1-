/* PERMITTED COMMANDS
   move(); turnLeft(); putLeaf(); removeLeaf();
*/
   
class MyClara extends Clara { 
    /**
     * In the 'run()' method you can write your program for Clara 
     */
    void run() {
        // TODO: Write your code below
         move();
        move();
        turnRight();
        move();
        removeLeaf();
        move();
        removeLeaf();
        move();
        removeLeaf();
        move();
        removeLeaf();
        move();
        removeLeaf();
        move();
        removeLeaf();
        move();
        removeLeaf();
        move();
        removeLeaf();
        move();
        removeLeaf();
        turnLeft();
        move();
        move();
        move();
        turnLeft();
        removeLeaf();
        move();
        removeLeaf();
        move();
        removeLeaf();
        move();
        removeLeaf();
        move();
        removeLeaf();
        move();
        removeLeaf();
        move();
        removeLeaf();
        move();
        turnRight();
        move();
        removeLeaf();
        move();
        turnLeft();
        move();
        removeLeaf();
        turnRight();
        move();
        turnRight();
        move();
        removeLeaf();
        move();
        turnLeft();
        move();
        turnRight();
        removeLeaf();
        move();
        removeLeaf();
        move();
        removeLeaf();
        turnRight();
        move();
        removeLeaf();
        move();
        removeLeaf();
        move();
        removeLeaf();
        move();
        turnLeft();
        turnLeft();
        move();
        move();
        move();
        move();
        turnRight();
        move();
        removeLeaf();
        move();
        removeLeaf();
        move();
        removeLeaf();
        move();
        removeLeaf();
        

    }
}